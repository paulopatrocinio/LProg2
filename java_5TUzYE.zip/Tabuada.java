public class Tabuada{
	public static void main(String[ ] args){
      int tabuada = 5; // tabuada do 5
      System.out.print("Tabuada do: " + tabuada +"\n");
      
      for(int x = 1; x <= 10; ++x){  
        System.out.print(tabuada + " x " + x + " = ");
        System.out.println(x * tabuada);
      }
    }
}