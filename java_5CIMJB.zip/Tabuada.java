public class Tabuada{
	public static void main(String[ ] args){
    	for(int n = 1; n<=10; ++n){
          System.out.print("\nTabuada do: " + n +"\n");  
            for(int x = 1; x <= 10; ++x){  
              System.out.print(n + " x " + x + " = ");
              System.out.println(x * n);
            }
      }
    }
}